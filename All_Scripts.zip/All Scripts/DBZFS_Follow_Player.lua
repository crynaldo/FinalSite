--[[ Breezy's Follow player script ]]
--[[ Join these servers: 
My Community server - https://discord.gg/Ez9Yx8qxvS
The Kidd's script server - https://discord.gg/eQzkActhfm 
and DM BreezyTheKidd#9999 for help or bug reports  
]]

local x = game.Players.LocalPlayer 
local partner = "CryaTheKidd" --[[ Put the person's username here ]]

game:GetService("RunService").RenderStepped:connect(function() wait()
x.Character.Humanoid:ChangeState(11)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.Live[partner].HumanoidRootPart.CFrame + Vector3.new(0, 0, 3) wait(1)
end)