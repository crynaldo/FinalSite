--[[
    This Script does not support Namekian on Namekian Slot Changing
]]

getgenv().Namekian = "Slot3"
getgenv().PointSlot = "Slot2"
getgenv().MaxPoints = math.huge --math.huge is basiclly inf so change it to what you want
getgenv().HideClientName = true --This hides The Users name to show proof of stat's
getgenv().CustomSlotChangeSpeed = 0.1 --This changes how fast you switch slots
getgenv().ReplicatedLag = 0 --This will simulate lag not make it so vpn is recommended but this sometimes can help
getgenv().KamiChatDelay = 0.125 --the Delay before you attempt to talk to kami after slot change dialog

-------------------------------------------------------------------------------------------------------------

loadstring(game:HttpGet("https://raw.githubusercontent.com/TheUnknownScripter/Roblox/main/DBZFS/Auto%20Inf%20Stat's"))()--[[

Welcome to Fluxus!

Do you need help with Fluxus? Join our discord! discord.gg\GNHbGPbah2

Check out Fluxus on Android! www.fluxteam.net/android

Tired of the keysystem and ads? Level up by purchasing Fluxus Premium!
Join our discord for more information OR check out www.bloxproducts.com/#fluxus

--]]