_G.key = "novembr" --the key is between the two " "
loadstring(game:HttpGet("https://raw.githubusercontent.com/NukeVsCity/TheALLHACKLoader/main/NukeLoader"))()


--Key for the manual loader is "      novembr      "