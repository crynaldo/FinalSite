-- put in auto execute (need all ki moves and god form)
loadstring(game:HttpGet("https://raw.githubusercontent.com/llCreepZll/llCreepZll/DBZFS_Scripts/autolag"))();