       --Made By Odium--

       local PointStat = "HM"
       local am = 0 -- The amount of stats you want it to put in --
   
   -- "Melee" for melee damage --
   -- "Ki" for ki damage --
   -- "HM" for Health --
   -- "KM" for Ki --
   -- "MR" for melee resistance --
   -- "KR" for ki resistance --
   -- "Speed" for speed --




if PointStat == "Melee" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Phys-Damage")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "Ki" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Ki-Damage")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "HM" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Health-Max")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "KM" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Ki-Max")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "MR" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Phys-Resist")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "KR" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats:FindFirstChild("Ki-Resist")
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end

if PointStat == "Speed" then
a = 0
repeat
a = a + 1
local args = {
    [1] = game:GetService("Players").LocalPlayer.PlayerGui.HUD.Bottom.Stats.Speed
}

game:GetService("Players").LocalPlayer.Backpack.ServerTraits.AttemptUpgrade:FireServer(unpack(args))
wait()
until a == am 
end