-------------------------------[Creado Por/Made By NabilDr-Ryo]------------------------------------

Settings = {
    Start = true; --[Don't change this value]--
    Vpnmode = false; --[Enable vpn mode]--
    UseReplicator = false; --[Enable replicatorlag mode]--
    ReplicatorLag = 0.14; --[Replicatorlag default value]--
    Rejoin = false; --[Activate auto rejoin after passing the seconds indicated in RejoinInTime]--
    RejoinTime = 7200; --[3600 = 1 hour   1800 = 30 mins]--
    AutoPing = false; --[Modifies the value of replicatorlag automatically until obtaining the ping indicated in AutoPinger]--
    AutoPinger = 240; --[Ping that the AutoPinger will try to get]--
    MaxPoints = 50000; --[Limit of points, put math.huge for an infinite amount]--
    Normal = "Slot1"; --[Slot that will get the points]--
    Namek = "Slot2"; --[Namekian slot required]--
    LowGFX = false; --[Remove unnecessary textures]--
    svhpmode = false; --[Serverhoop instead of closing the game, this will only move you between public servers]--
    webhookmode = false; --[Activate the sending of stats information to your webhook]--
    CooldownSlots = 0.125; --[Cooldown between slot change messages - recommended 0.1 / low pc recommended 0.2]--
    webhooklink = "";  --[put your own weebhook to get your lvl up info in discord]--
    CrashMode = true; --[The game will be closed to be able to use in combination with Warline Reloader]--
}



-------------------------------[Warn this is a free script]--------------------------------------
------------------------------\(👍≖‿‿≖)👍 👍(≖‿‿≖👍)/--------------------------------------



loadstring(game:HttpGet'https://raw.githubusercontent.com/NeiKiNDR/NDR2023/main/ISparte1.lua')()
