local Time = 15
local r = game.RunService.Heartbeat:connect(function()
    game.Players.LocalPlayer.Backpack.ServerTraits.EatSenzu:FireServer(true)
    game.Players.LocalPlayer.Backpack.ServerTraits.ChatStart:FireServer(unpack({[1] = workspace.FriendlyNPCs:FindFirstChild("Hair Stylist")}))
          task.wait()
          game.Players.LocalPlayer.Backpack.ServerTraits.ChatAdvance:FireServer(unpack({[1] = {[1] = "Yes"}}))
          task.wait()
          game:GetService("Players").LocalPlayer.Backpack:WaitForChild("HairScript").RemoteEvent:FireServer(unpack({[1] = "woah"}))
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local currentCFrame = LocalPlayer.Character.HumanoidRootPart.CFrame
    local heartbeatConn = game.RunService.Heartbeat:connect(function()
        LocalPlayer.Character.HumanoidRootPart.CFrame = currentCFrame
    end)
    wait(2.8)
    heartbeatConn:Disconnect()
end)
wait(Time)
r:Disconnect()